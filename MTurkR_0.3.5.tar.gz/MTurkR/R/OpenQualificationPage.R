OpenQualificationPage <-
function () 
{
    shell.exec("https://requester.mturk.com/qualification_types")
}
